import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import {analyze,exportVideo} from '../dist/engine.mjs';
import {makeMoov,boxes,child,u32} from '../dist/mp4.mjs';
const root=fileURLToPath(new URL('..',import.meta.url)),generated=path.join(root,'tests/.generated');fs.mkdirSync(generated,{recursive:true});
const ffmpeg=process.env.FFMPEG_BIN||'ffmpeg';
function run(exe,args){const r=spawnSync(exe,args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});if(r.status!==0)throw Error(r.stderr||r.error?.message||r.stdout);return r.stdout;}
const ff=args=>run(ffmpeg,['-hide_banner','-loglevel','error','-y',...args]);
for(const name of ['reference','hevc','fractional','multitrack']){
  const fps=name==='fractional'?'24000/1001':'25',time=name==='fractional'?'3.003':'3',base='tests/.generated/'+name;
  const inputs=['-f','lavfi','-i',`testsrc2=size=320x180:rate=${fps}`,'-f','lavfi','-i','sine=frequency=440:sample_rate=48000'];
  if(name==='multitrack')inputs.push('-f','lavfi','-i','sine=frequency=880:sample_rate=48000');
  const enc=name==='hevc'?['-c:v','libx265','-tag:v','hvc1','-x265-params','aud=1:keyint=12:min-keyint=12:scenecut=0:open-gop=0:pools=none:log-level=error']:['-c:v','libx264','-x264-params','aud=1:keyint=12:min-keyint=12:scenecut=0:open-gop=0'];
  ff([...inputs,'-t',time,...(name==='multitrack'?['-map','0:v','-map','1:a','-map','2:a']:[]),...enc,'-pix_fmt','yuv420p','-c:a','pcm_s16le','-ac',name==='multitrack'?'1':'2',base+'.mov']);
  run('node',['tests/fixtures.mjs',name]);run('node',['tests/check.mjs',name]);
  for(const kind of ['mov','_recovered.mp4']){
    const input=base+(kind==='mov'?'.mov':kind),suffix=kind==='mov'?'original':'recovered';
    ff(['-i',input,'-map','0:v:0','-f','framemd5',base+'-'+suffix+'.md5']);
    for(let i=0;i<(name==='multitrack'?2:1);i++)ff(['-i',input,'-map',`0:a:${i}`,'-f','s16le',base+'-'+suffix+i+'.pcm']);
  }
  assert.equal(fs.readFileSync(basePath(base+'-original.md5'),'utf8'),fs.readFileSync(basePath(base+'-recovered.md5'),'utf8'));
  for(let i=0;i<(name==='multitrack'?2:1);i++)assert.deepEqual(fs.readFileSync(basePath(base+'-original'+i+'.pcm')),fs.readFileSync(basePath(base+'-recovered'+i+'.pcm')));
  ff(['-i',base+'_partial.mp4','-f','null','-']);
  console.log(`PASS ${name}: decoded frame hashes + timestamps match; decoded PCM matches; truncated tail decodes.`);
}
function basePath(p){return path.join(root,p);}
const input=new Blob([fs.readFileSync(path.join(generated,'reference.rsv'))]),ref=new Blob([fs.readFileSync(path.join(generated,'reference.mov'))]);
const job=await analyze(input,ref);const chunks=[];let closed=false;
await exportVideo(job,{createWritable:async()=>({write:async a=>chunks.push(a),close:async()=>{closed=true;},abort:async()=>{}})});
assert(closed);assert.deepEqual(Buffer.from(await new Blob(chunks).arrayBuffer()),Buffer.from(await(await exportVideo(job)).arrayBuffer()));
let aborted=false;await assert.rejects(()=>exportVideo(job,{createWritable:async()=>({write:async()=>{throw Error('disk full');},close:async()=>{},abort:async()=>{aborted=true;}})}),/disk full/);assert(aborted);
const many={...job.index,frames:Array.from({length:150000},(_,i)=>({offset:2**32+i*100,size:100,poc:i,idr:i===0,key:i===0})),audio:job.index.audio.map(()=>[])};
const moov=boxes(makeMoov(job.ref,many,32))[0],trak=child(moov,'trak'),co=child(child(child(child(trak,'mdia'),'minf'),'stbl'),'co64');
assert.equal(u32(co.data,4),150000);assert.equal(new DataView(co.data.buffer,co.data.byteOffset).getBigUint64(8),BigInt(2**32+32));
console.log('PASS streaming export, disk-full abort, 150k-frame metadata, 64-bit offsets.');

console.log(run('node',['tests/auto.mjs']).trim());
console.log(run('node',['tests/sony.mjs']).trim());
for(const name of ['reference','hevc','fractional','big-endian','fragmented','sony']){
  const base='tests/.generated/'+name,expected=['big-endian','fragmented','sony'].includes(name)?'reference':name;
  ff(['-i',base+'-auto.mp4','-map','0:v:0','-f','framemd5',base+'-auto.md5']);
  assert.equal(fs.readFileSync(basePath(base+'-auto.md5'),'utf8'),fs.readFileSync(basePath('tests/.generated/'+expected+'-original.md5'),'utf8'));
  ff(['-i',base+'-auto.mp4','-map','0:a:0','-f','s16le',base+'-auto.pcm']);
  assert.deepEqual(fs.readFileSync(basePath(base+'-auto.pcm')),fs.readFileSync(basePath('tests/.generated/'+expected+'-original0.pcm')));
  console.log('PASS '+name+': donor-free decoded frame hashes/timestamps and PCM match.');
}

console.log(run('node',['tests/save-ui.mjs']).trim());

console.log(run('node',['tests/parameters.mjs']).trim());
for(const name of ['reference','hevc'])for(const where of ['metadata','in-band']){
  const base='tests/.generated/'+name;
  ff(['-xerror','-i',base+'-late-'+where+'.mp4','-map','0:v','-f','framemd5',base+'-late-'+where+'.md5']);
  assert.equal(fs.readFileSync(basePath(base+'-late-'+where+'.md5'),'utf8'),fs.readFileSync(basePath(base+'-original.md5'),'utf8'));
}
console.log('PASS late AVC/HEVC metadata/in-band parameters: decoded frame hashes and timestamps match.');
console.log(run('node',['tests/settings.mjs']).trim());

console.log(run('node',['tests/large-stream.mjs']).trim());
