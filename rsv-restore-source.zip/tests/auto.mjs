import fs from 'node:fs/promises';import assert from 'node:assert/strict';
import {readReference,box,word,join,u16}from'../dist/mp4.mjs';
import {detectReference,rtmd}from'../dist/detect.mjs';
import {analyze,exportVideo}from'../dist/engine.mjs';
const root=new URL('./.generated/',import.meta.url);
for(const name of ['reference','hevc','fractional']){
  const donor=new Blob([await fs.readFile(new URL(name+'.mov',root))]),rsv=new Uint8Array(await fs.readFile(new URL(name+'.rsv',root))),ref=await readReference(donor);
  const tag=join(Uint8Array.of(129,6,0,8),word(ref.video.timescale),word(ref.video.delta));
  let cfg=ref.video.config;
  if(ref.video.codec==='hvc1'){const header=cfg.slice(0,23),arrays=[];let p=23;for(let i=0;i<cfg[22];i++){const begin=p,type=cfg[p++]&63,count=u16(cfg,p);p+=2;for(let j=0;j<count;j++){const n=u16(cfg,p);p+=2+n;}if([32,33,34].includes(type))arrays.push(cfg.slice(begin,p));}header[22]=arrays.length;cfg=join(header,...arrays);}
  const config=box(ref.video.codec==='avc1'?'avcC':'hvcC',cfg);
  for(let p=0;p<rsv.length-28;p++)if(rtmd(rsv,p))rsv.set(join(tag,config),p+28);
  await fs.writeFile(new URL(name+'-embedded.rsv',root),rsv);
  const detected=await detectReference(new Blob([rsv]),{log:console.log});
  assert.equal(detected.video.width,ref.video.width);assert.equal(detected.video.height,ref.video.height);
  assert(Math.abs(detected.video.timescale/detected.video.delta-ref.video.timescale/ref.video.delta)<1e-8);
  assert.equal(detected.audio[0].codec,ref.audio[0].codec);
  const job=await analyze(new Blob([rsv]),undefined);assert.equal(job.index.frames.length,name==='fractional'?72:75);
  await fs.writeFile(new URL(name+'-auto.mp4',root),Buffer.from(await(await exportVideo(job)).arrayBuffer()));
  console.log('PASS automatic config + PCM inference:',name);
}
const missing=new Blob([await fs.readFile(new URL('reference.rsv',root))]);
await assert.rejects(()=>detectReference(missing),e=>e.kind==='needs-donor');
await assert.rejects(()=>detectReference(new Blob([])),e=>e.kind==='empty');
await assert.rejects(()=>detectReference(new Blob([new Uint8Array(1024)])),e=>e.kind==='not-rsv');
console.log('PASS explicit donor fallback / empty / unknown.');

// Same raw PCM, byte-swapped to big-endian, must be identified and recovered.
const refFile=new Blob([await fs.readFile(new URL('reference.mov',root))]);
const embedded=new Uint8Array(await fs.readFile(new URL('reference-embedded.rsv',root)));
const indexed=await analyze(new Blob([embedded]),refFile);
for(const chunk of indexed.index.audio[0])for(let p=chunk.offset;p<chunk.offset+chunk.count*4;p+=2){const v=embedded[p];embedded[p]=embedded[p+1];embedded[p+1]=v;}
const bigJob=await analyze(new Blob([embedded]));assert.equal(bigJob.ref.audio[0].codec,'twos');
await fs.writeFile(new URL('big-endian-auto.mp4',root),Buffer.from(await(await exportVideo(bigJob)).arrayBuffer()));

// A length-prefixed SPS split across two f010 metadata payloads.
const avc=(await readReference(refFile)).video.config,nals=[];let c=6;
for(let i=0;i<(avc[5]&31);i++){const n=u16(avc,c);c+=2;nals.push(avc.slice(c,c+n));c+=n;}
const count=avc[c++];for(let i=0;i<count;i++){const n=u16(avc,c);c+=2;nals.push(avc.slice(c,c+n));c+=n;}
const payload=join(new Uint8Array(1990),...nals.flatMap(n=>[word(n.length),n]));
const header=Uint8Array.of(0,28,1,0,3,4,5,6,240,1,0,16),first=new Uint8Array(2048),second=new Uint8Array(2048),tag=join(Uint8Array.of(129,6,0,8),word(25),word(1));
for(const [i,a]of[first,second].entries()){
  a.set(header);a.set(tag,28);const part=i===0?payload.slice(0,2004):payload.slice(2004);a.set(Uint8Array.of(240,16,part.length>>8,part.length&255),40);a.set(part,44);
}
const original=new Uint8Array(await fs.readFile(new URL('reference.rsv',root)));
const fragmented=new Blob([first,second,original.slice(2048)]),fragmentJob=await analyze(fragmented);
assert.equal(fragmentJob.index.frames.length,75);
await fs.writeFile(new URL('fragmented-auto.mp4',root),Buffer.from(await(await exportVideo(fragmentJob)).arrayBuffer()));
console.log('PASS big-endian PCM, bare NAL harvest, metadata-boundary SPS reassembly.');
