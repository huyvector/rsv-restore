import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {readReference,word,join,box} from '../dist/mp4.mjs';
import {configNals,parameterKey,sonyParameters} from '../dist/detect.mjs';
import {Bits} from '../dist/codec.mjs';
import {analyze,exportVideo} from '../dist/engine.mjs';
const dir=new URL('./.generated/',import.meta.url);
for(const hevc of [false,true]){
 const name=hevc?'hevc':'reference',donor=new Blob([await fs.readFile(new URL(name+'.mov',dir))]);
 const ref=await readReference(donor),nals=configNals(ref.video.config,hevc),type=hevc?34:8;
 const pps=nals.find(n=>(hevc?(n[0]>>1)&63:n[0]&31)===type),header=hevc?2:1,bits=new Bits(pps,header);
 assert.equal(bits.ue(),0);let rest=bits.a.map(b=>b.toString(2).padStart(8,'0')).join('').slice(bits.p);rest=rest.slice(0,rest.lastIndexOf('1')+1);
 let encoded='010'+rest;encoded=encoded.padEnd(Math.ceil(encoded.length/8)*8,'0');
 const out=Array.from(pps.slice(0,header));let zeros=0;
 for(let p=0;p<encoded.length;p+=8){const b=parseInt(encoded.slice(p,p+8),2);if(zeros>=2&&b<=3){out.push(3);zeros=0;}out.push(b);zeros=b===0?zeros+1:0;}
 const late=Uint8Array.from(out),record=join(Uint8Array.of(0,16,2,0,1),word(hevc?2:1),word(late.length),Uint8Array.of(0),word(late.length+4),Uint8Array.of(2,1),late);
 assert.equal(parameterKey(sonyParameters(record,hevc)[0],hevc),`${type}:1`);
 const raw=new Uint8Array(await fs.readFile(new URL(name+'-embedded.rsv',dir))),base=await analyze(new Blob([raw]));
 for(const where of ['metadata','in-band']){
  let input;
  if(where==='metadata'){const changed=raw.slice();changed.set(record,base.index.groups[1].end+28);input=new Blob([changed]);}
  else{const p=base.index.frames[24].offset+(hevc?7:6);input=new Blob([raw.slice(0,p),word(late.length),late,raw.slice(p)]);}
  const job=await analyze(input);assert.equal(job.index.frames.length,75);
  const result=await exportVideo(job),cfg=(await readReference(result)).video.config;
  assert(configNals(cfg,hevc).some(n=>parameterKey(n,hevc)===`${type}:1`));
  await fs.writeFile(new URL(name+'-late-'+where+'.mp4',dir),Buffer.from(await result.arrayBuffer()));
 }
 const bad=raw.slice(),conflict=pps.slice();conflict[conflict.length-1]^=16;
 const badRecord=join(Uint8Array.of(0,16,2,0,0),word(hevc?2:1),word(conflict.length),Uint8Array.of(0),word(conflict.length+4),Uint8Array.of(2,1),conflict);
 bad.set(badRecord,base.index.groups[1].end+28);
 await assert.rejects(()=>analyze(new Blob([bad])),/Cấu hình codec/);
 console.log(`PASS ${hevc?'HEVC':'AVC'}: late metadata/in-band PPS retained in output config; same-ID changes rejected.`);
}
