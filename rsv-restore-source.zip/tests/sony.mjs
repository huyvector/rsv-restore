import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {readReference,word,join} from '../dist/mp4.mjs';
import {configNals,sonyParameters,inspectSps} from '../dist/detect.mjs';
import {analyze,exportVideo} from '../dist/engine.mjs';
import {Bits} from '../dist/codec.mjs';
const root=new URL('./.generated/',import.meta.url);
const donor=new Blob([await fs.readFile(new URL('reference.mov',root))]);
const ref=await readReference(donor),nals=configNals(ref.video.config,false);
function record(n){const type=n[0]&31,id=type===7?inspectSps(n).id:new Bits(n).ue();return join(Uint8Array.of(0,16,2,0,id),word(type===7?0:1),word(n.length),Uint8Array.of(0),word(n.length+4),Uint8Array.of(2,1),n);}
// Add another PPS ID with the same syntax. Its ue(v) occupies two more
// bits than ID 0; re-encode RBSP and emulation-prevention bytes correctly.
const originalPps=nals.find(n=>(n[0]&31)===8),bits=new Bits(originalPps);
assert.equal(bits.ue(),0);
let syntax=bits.a.map(v=>v.toString(2).padStart(8,'0')).join('').slice(bits.p);
syntax=syntax.slice(0,syntax.lastIndexOf('1')+1);
let updated='010'+syntax;updated=updated.padEnd(Math.ceil(updated.length/8)*8,'0');
const escaped=[originalPps[0]];let zeros=0;
for(let i=0;i<updated.length;i+=8){const b=parseInt(updated.slice(i,i+8),2);if(zeros>=2&&b<=3){escaped.push(3);zeros=0;}escaped.push(b);zeros=b===0?zeros+1:0;}
const latePps=Uint8Array.from(escaped);
const packet=record(latePps);assert.equal(new Bits(sonyParameters(packet)[0]).ue(),1);
const bad=packet.slice();bad[17]^=1;assert.equal(sonyParameters(bad).length,0);
const input=new Uint8Array(await fs.readFile(new URL('reference.rsv',root)));
const baseline=await analyze(new Blob([input]),donor);
input.set(join(Uint8Array.of(129,6,0,8),word(25),word(1),...nals.map(record)),28);
const lateGroup=baseline.index.groups[1].end;
input.set(record(latePps),lateGroup+28);
for(const reference of [undefined,donor]){
 const job=await analyze(new Blob([input]),reference);
 assert.equal(job.index.frames.length,75);
 const out=await exportVideo(job),result=await readReference(out);
 assert(configNals(result.video.config,false).some(n=>(n[0]&31)===8&&new Bits(n).ue()===1));
 if(!reference)await fs.writeFile(new URL('sony-auto.mp4',root),Buffer.from(await out.arrayBuffer()));
}
console.log('PASS Sony envelope validation, donor-free recovery, late PPS merged into decoder config with/without donor.');
