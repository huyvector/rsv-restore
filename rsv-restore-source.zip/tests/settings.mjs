// Generated codec/settings coverage, not a claim of camera/firmware coverage.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {analyze,exportVideo} from '../dist/engine.mjs';
import {readReference,word,join,box,ascii} from '../dist/mp4.mjs';
import {configNals,rtmd,sonyParameters,parameterKey,detectReference} from '../dist/detect.mjs';
const root=fileURLToPath(new URL('..',import.meta.url)),out=path.join(root,'tests/.generated');
const ffmpeg=process.env.FFMPEG_BIN||'ffmpeg';
function run(exe,args){const p=spawnSync(exe,args,{cwd:root,encoding:'utf8',maxBuffer:8*1024*1024});if(p.status!==0)throw Error(p.stderr||p.error?.message||p.stdout);return p.stdout;}
const ff=args=>run(ffmpeg,['-hide_banner','-loglevel','error','-y',...args]);
const cases=[
 {name:'avc422-50',fps:'50',pix:'yuv422p10le',hevc:false,frames:100},
 {name:'hevc422-50',fps:'50',pix:'yuv422p10le',hevc:true,frames:100},
 {name:'hevc420-5994',fps:'60000/1001',pix:'yuv420p10le',hevc:true,frames:120},
 {name:'avc-intra-24',fps:'24',pix:'yuv420p',hevc:false,frames:48,intra:true},
 {name:'avc-4mono24',fps:'50',pix:'yuv420p',hevc:false,frames:100,multi:true},
];
for(const c of cases.filter(c=>!process.env.SETTING_CASE||c.name===process.env.SETTING_CASE)){
 const base=path.join(out,c.name),gop=c.intra?1:24;
 const inputs=['-f','lavfi','-i',`testsrc2=size=640x360:rate=${c.fps}`];
 for(let j=0;j<(c.multi?4:1);j++)inputs.push('-f','lavfi','-i',`sine=frequency=${440+j*220}:sample_rate=48000`);
 const maps=['-map','0:v'];for(let j=0;j<(c.multi?4:1);j++)maps.push('-map',`${j+1}:a`);
 const params=`aud=1:keyint=${gop}:min-keyint=${gop}:scenecut=0:open-gop=0`;
 const enc=c.hevc?['-c:v','libx265','-tag:v','hvc1','-x265-params',params+':pools=none:log-level=error']:['-c:v','libx264','-x264-params',params+':slices=4'];
 ff([...inputs,...maps,'-t',String(c.frames/(evalRatio(c.fps))),...enc,'-pix_fmt',c.pix,'-c:a',c.multi?'pcm_s24be':'pcm_s16le','-ac',c.multi?'1':'2',base+'.mov']);
 run('node',['tests/fixtures.mjs',c.name]);
 const donor=new Blob([fs.readFileSync(base+'.mov')]),ref=await readReference(donor),raw=new Uint8Array(fs.readFileSync(base+'.rsv'));
 assert.equal(ref.audio.length,c.multi?4:1);
 if(c.multi)assert(ref.audio.every(a=>a.bits===24&&a.bytes===3));
 const nals=configNals(ref.video.config,c.hevc).filter(n=>(c.hevc?[32,33,34]:[7,8]).includes(c.hevc?(n[0]>>1)&63:n[0]&31));
 if(!c.multi){
  const records=nals.map(n=>{const [type,id]=parameterKey(n,c.hevc).split(':').map(Number);return join(Uint8Array.of(0,16,2,0,id),word(c.hevc?type-32:type===7?0:1),word(n.length),Uint8Array.of(0),word(n.length+4),Uint8Array.of(2,1),n);});
  const embedded=join(Uint8Array.of(129,6,0,8),word(ref.video.timescale),word(ref.video.delta),...records);
  assert.equal(sonyParameters(embedded,c.hevc).length,nals.length);
  const damaged=embedded.slice();damaged[12+17]^=1;assert.equal(sonyParameters(damaged,c.hevc).length,nals.length-1);
  for(let p=0;p<raw.length-28;p++)if(rtmd(raw,p))raw.set(embedded,p+28);
 }
 const file=new Blob([raw]);
 const job=await analyze(file,c.multi?donor:undefined);assert.equal(job.index.frames.length,c.frames);
 const recovered=await exportVideo(job);fs.writeFileSync(base+'-recovered.mp4',Buffer.from(await recovered.arrayBuffer()));
 fs.writeFileSync(base+'-test.rsv',raw);
 for(const [suffix,input]of[['original',base+'.mov'],['recovered',base+'-recovered.mp4']]){
  ff(['-xerror','-i',input,'-map','0:v','-f','framemd5',base+'-'+suffix+'.md5']);
  for(let j=0;j<ref.audio.length;j++)ff(['-xerror','-i',input,'-map',`0:a:${j}`,'-c:a','pcm_s32le','-f','s32le',base+'-'+suffix+j+'.pcm']);
 }
 assert.equal(fs.readFileSync(base+'-original.md5','utf8'),fs.readFileSync(base+'-recovered.md5','utf8'));
 for(let j=0;j<ref.audio.length;j++)assert.deepEqual(fs.readFileSync(base+'-original'+j+'.pcm'),fs.readFileSync(base+'-recovered'+j+'.pcm'));
 if(c.name==='avc422-50'){
  // Interrupted MP4 with a declared mdat larger than the downloaded prefix.
  const header=join(box('ftyp',ascii('XAVC'),word(0),ascii('XAVC')),word(0x7fffffff),ascii('mdat'));
  const partial=new Blob([header,raw]);assert.equal((await analyze(partial)).index.frames.length,c.frames);
  await assert.rejects(()=>detectReference(donor),e=>e.kind==='complete');
 }
 console.log(`PASS settings ${c.name}: ${c.frames} frames, hashes/timestamps + ${ref.audio.length} PCM track(s) match; ${c.multi?'donor required':'donor-free'}.`);
}
function evalRatio(s){const [a,b=1]=s.split('/').map(Number);return a/b;}
