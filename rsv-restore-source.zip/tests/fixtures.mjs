import fs from 'node:fs/promises';
import {readReference,u32,requireChild,child} from '../dist/mp4.mjs';
const root=new URL('./.generated/',import.meta.url);
export async function samples(file,track){
  const stbl=track.stbl,sz=requireChild(stbl,'stsz').data,fixed=u32(sz,4),n=u32(sz,8),sc=requireChild(stbl,'stsc').data,offsets=(child(stbl,'co64')||child(stbl,'stco')),a=offsets.data,wide=offsets.type==='co64';
  const rules=Array.from({length:u32(sc,4)},(_,i)=>({start:u32(sc,8+i*12),count:u32(sc,12+i*12)})),result=[];let id=0,rule=0;
  for(let i=0;i<u32(a,4);i++){
    while(rules[rule+1]?.start<=i+1)rule++;
    let off=wide?Number(new DataView(a.buffer,a.byteOffset).getBigUint64(8+i*8)):u32(a,8+i*4);
    for(let j=0;j<rules[rule].count&&id<n;j++,id++){const size=fixed||u32(sz,12+id*4);result.push({offset:off,size});off+=size;}
  }return result;
}
const name=process.argv[2]||'reference';
const data=await fs.readFile(new URL(name+'.mov',root)),file=new Blob([data]),ref=await readReference(file),vs=await samples(file,ref.video),audios=[];
for(const a of ref.audio){const ss=await samples(file,a);audios.push(Buffer.concat(ss.map(s=>data.subarray(s.offset,s.offset+s.size))));}
const sync=child(ref.video.stbl,'stss')?.data,keys=sync?Array.from({length:u32(sync,4)},(_,i)=>u32(sync,8+i*4)-1):vs.map((_,i)=>i),parts=[];
for(let g=0;g<keys.length;g++){
  const begin=keys[g],end=keys[g+1]??vs.length,packet=2048,metadata=Buffer.alloc(packet*(1+g%3));
  for(let p=0;p<metadata.length;p+=packet){metadata.set([0,28,1,0,3,4,5,6,240,1,0,16],p);}
  parts.push(metadata,...vs.slice(begin,end).map(s=>{
    const frame=data.subarray(s.offset,s.offset+s.size);let p=0;
    while(p+5<frame.length){const n=u32(frame,p),type=ref.video.codec==='avc1'?frame[p+4]&31:(frame[p+4]>>1)&63;if(type===(ref.video.codec==='avc1'?9:35)){if(p)return Buffer.concat([frame.subarray(p,p+4+n),frame.subarray(0,p),frame.subarray(p+4+n)]);return frame;}p+=4+n;}
    return Buffer.concat([ref.video.codec==='avc1'?Buffer.from([0,0,0,2,9,16]):Buffer.from([0,0,0,3,70,1,16]),frame]);
  }));
  ref.audio.forEach((a,j)=>{const start=Math.round(begin*ref.video.delta*a.timescale/ref.video.timescale)*a.bytes,finish=Math.round(end*ref.video.delta*a.timescale/ref.video.timescale)*a.bytes;parts.push(audios[j].subarray(start,finish));});
}
await fs.writeFile(new URL(name+'.rsv',root),Buffer.concat(parts));
console.log(JSON.stringify({name,frames:vs.length,groups:keys.length,codec:ref.video.codec}));
