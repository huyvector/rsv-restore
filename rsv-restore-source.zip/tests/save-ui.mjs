import fs from 'node:fs/promises';import vm from 'node:vm';import assert from 'node:assert/strict';
const code=await fs.readFile(new URL('../dist/app.mjs',import.meta.url),'utf8');
function app(zone,stored,hasPicker=true){
 const elements=new Map(),sent=[],storage=new Map(stored?[['rsv-restore-language',stored]]:[]);
 function el(id){if(!elements.has(id))elements.set(id,{id,events:{},hidden:false,open:false,addEventListener(e,f){this.events[e]=f;},removeAttribute(){},setAttribute(k,v){this[k]=v;},load(){},showModal(){this.open=true;},close(){this.open=false;},classList:{add(){},remove(){}}});return elements.get(id);}
 class Worker{constructor(){Worker.current=this;}terminate(){}postMessage(m){sent.push(m);}}
 const document={documentElement:{},getElementById:el,querySelectorAll:()=>[]};
 const context=vm.createContext({document,window:hasPicker?{showSaveFilePicker:async()=>({name:'sample_recovered.mp4'})}:{},Intl:{DateTimeFormat:()=>({resolvedOptions:()=>({timeZone:zone})})},localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},Worker,URL,Blob,console});
 new vm.Script(code).runInContext(context);return {el,document,sent,storage,Worker};
}
for(const [zone,expected]of[['Asia/Ho_Chi_Minh','vi'],['Asia/Saigon','vi'],['Asia/Bangkok','en'],['America/New_York','en'],['Europe/London','en']])assert.equal(app(zone).document.documentElement.lang,expected);
const a=app('Asia/Saigon','en');assert.equal(a.document.documentElement.lang,'en');a.el('lang-vi').events.click();assert.equal(a.storage.get('rsv-restore-language'),'vi');a.el('lang-auto').events.click();assert.equal(a.document.documentElement.lang,'vi');
assert.equal(a.el('reference-dialog').open,false);
a.el('rsv-input').events.change({target:{files:[{name:'sample.RSV',size:256*1024**3}]}});
assert.equal(a.sent.at(-1).type,'analyze');assert.equal(a.el('reference-dialog').open,false);
a.Worker.current.onmessage({data:{type:'error',kind:'needs-donor',stage:'analyze'}});assert.equal(a.el('reference-dialog').open,true);
a.el('ref-input').events.change({target:{files:[{name:'donor.MP4',size:1234}]}});assert.equal(a.el('reference-dialog').open,false);assert.equal(a.sent.at(-1).reference.name,'donor.MP4');
a.Worker.current.onmessage({data:{type:'ready',codec:'avc1',width:3840,height:2160,fps:60,seconds:10,warnings:[],limited:true}});
a.Worker.current.onmessage({data:{type:'metrics',readMBps:250.125,writeMBps:123.456}});assert.equal(a.el('read-speed').textContent,'250.1 MB/s');assert.equal(a.el('write-speed').textContent,'123.5 MB/s');
await a.el('export').events.click();assert.equal(a.sent.at(-1).type,'export');assert.equal(a.sent.at(-1).handle.name,'sample_recovered.mp4');
a.el('cancel').events.click();assert.equal(a.sent.at(-1).type,'cancel');
a.Worker.current.onmessage({data:{type:'cancelled'}});assert.equal(a.el('status-chip').textContent,'Đã hủy');
const b=app('America/New_York',undefined,false);b.el('rsv-input').events.change({target:{files:[{name:'large.RSV',size:256*1024**3}]}});b.Worker.current.onmessage({data:{type:'ready',codec:'avc1',width:3840,height:2160,fps:60,seconds:10,warnings:[],limited:true}});assert.equal(b.el('export').disabled,true);
const c=app('Europe/London');c.el('rsv-input').events.change({target:{files:[{name:'sample.RSV',size:1024}]}});c.Worker.current.onmessage({data:{type:'ready',codec:'avc1',width:320,height:180,fps:25,seconds:3,warnings:[],limited:false}});await c.el('export').events.click();assert.equal(c.sent.at(-1).type,'export');
c.Worker.current.onmessage({data:{type:'error',stage:'save',kind:'failed'}});assert.equal(c.el('reference-dialog').open,false);
console.log('PASS timezone/override/persistence, donor popup only after analysis failure, 256 GiB selection, save/cancel, real metrics, browser fallback, donor-free export.');
