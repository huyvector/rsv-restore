import assert from 'node:assert/strict';import {exportVideo} from '../dist/engine.mjs';
const chunk=32*1024**2,block=new ArrayBuffer(chunk),size=256*1024**3+12345;let next=0,written=0,max=0,closed=false,reported=0;
const file={size,slice(start,end){assert.equal(start,next);const length=Math.min(size,end)-start;next+=length;return {arrayBuffer:async()=>length===chunk?block:new ArrayBuffer(length)};}};
const job={file,ref:{ftyp:new Uint8Array(24)},moov:new Uint8Array(100)};
await exportVideo(job,{createWritable:async()=>({write:async x=>{written+=x.byteLength;max=Math.max(max,x.byteLength);},close:async()=>{closed=true;},abort:async()=>assert.fail()})},{onWrite:n=>reported+=n});
assert.equal(written,size+24+16+100);assert.equal(reported,written);assert.equal(next,size);assert.equal(max,chunk);assert(closed);
let aborted=false;const controller=new AbortController();
await assert.rejects(()=>exportVideo({...job,file:{size:chunk*2,slice:()=>({arrayBuffer:async()=>block})}},{createWritable:async()=>({write:async x=>{if(x.byteLength===chunk)controller.abort();},close:async()=>assert.fail(),abort:async()=>{aborted=true;}})},{signal:controller.signal}),e=>e.name==='AbortError');assert(aborted);
console.log('PASS virtual 256 GiB + tail export: exact byte totals, <=32 MiB writes, backpressure and cooperative abort. This is a virtual stream test, not a 256 GiB real-camera recovery.');
